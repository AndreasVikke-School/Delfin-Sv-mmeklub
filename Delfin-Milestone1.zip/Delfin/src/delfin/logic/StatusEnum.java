package delfin.logic;

/**
 *
 * @author Andreas Vikke
 */
public enum StatusEnum {
    ACTIVE, PASIVE
}
