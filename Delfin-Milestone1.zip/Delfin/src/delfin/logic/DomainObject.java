package delfin.logic;

/**
 *
 * @author Andreas Vikke
 */
public class DomainObject extends Object {

}
