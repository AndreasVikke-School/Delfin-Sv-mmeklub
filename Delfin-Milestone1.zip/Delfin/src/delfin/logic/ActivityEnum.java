package delfin.logic;

/**
 *
 * @author Andreas Vikke
 */
public enum ActivityEnum {
    EXERCISER, COMPETITIOR
}
