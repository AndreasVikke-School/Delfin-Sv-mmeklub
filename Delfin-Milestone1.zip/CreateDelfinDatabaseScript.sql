DROP TABLE if exists `activityinfo`;

CREATE TABLE `activityinfo` (
  `ssn` varchar(10) NOT NULL,
  `status` int(11) NOT NULL,
  `team` int(11) NOT NULL,
  `activity` int(11) NOT NULL,
  PRIMARY KEY (`ssn`),
  UNIQUE KEY `ssn_UNIQUE` (`ssn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE if exists `member`;

CREATE TABLE `member` (
  `ssn` varchar(10) NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `phone` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`ssn`),
  UNIQUE KEY `ssn_UNIQUE` (`ssn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE if exists `quota`;

CREATE TABLE `quota` (
  `ssn` varchar(10) NOT NULL,
  `subscription` double DEFAULT NULL,
  `paid` double DEFAULT NULL,
  `createdate` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

DROP TABLE if exists `results`;

CREATE TABLE `results` (
  `ssn` varchar(10) NOT NULL,
  `date` date DEFAULT NULL,
  `time` double DEFAULT NULL,
  `placement` int(11) DEFAULT NULL,
  `event` varchar(45) DEFAULT NULL,
  `disciplin` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;